^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_robot_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.4 (2016-07-15)
------------------

1.0.3 (2016-07-13)
------------------

1.0.2 (2016-07-06)
------------------
* Modified authors and maintainers
* modified CMakeLists y Package files
* Contributors: carlos3dx

1.0.1 (2016-07-04)
------------------
* Modified CMakeLists and package files
* Adding compilation dependencies with robotnik_msgs
* updated to set speed to 0 when no commands received - todo, add brakes
* updateodometry corrected
* by default publish odom->base_link
* added rbcar_robot_control launch and config folders and files
* changed joint names and controller topics
* added rbcar_robot_control
* Contributors: Usuario, carlos3dx, rguzman
