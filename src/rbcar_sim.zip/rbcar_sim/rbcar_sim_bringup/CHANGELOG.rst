^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_sim_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.4 (2016-07-15)
------------------
* added launch to test in gs world with teb
* Contributors: rguzman1

1.0.3 (2016-07-13)
------------------

1.0.2 (2016-07-06)
------------------
* Modified authors and maintainers
* modified CMakeLists y Package files
* Contributors: carlos3dx

1.0.1 (2016-07-04)
------------------
* Modified CMakeLists and package files
* added cfg for gps and odom robot_localization
* added marker size to view them when the rbcar is on them
* added purepursuit custom launch files
* added sim bringup
* added rbcar_sim_bringup
* Contributors: carlos3dx, rguzman, rguzman1
