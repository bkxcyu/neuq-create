^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_pad
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.5 (2016-07-13)
------------------

1.0.4 (2016-07-06)
------------------

1.0.3 (2016-07-05)
------------------
* modified dependencies
* Contributors: carlos3dx

1.0.2 (2016-07-04)
------------------
* Added dependencies
* Contributors: carlos3dx

1.0.1 (2016-07-04)
------------------
* Added website
* Modified dependencies
* rbcar_description: changing 3d sensor position to fit with the real model
* rbcar_pad: enabling params like max speed and steering angle
* Adding compilation dependencies with robotnik_msgs
* Adding new package rbcar_pad for sim and real robot
* Contributors: RomanRobotnik, Usuario, carlos3dx
