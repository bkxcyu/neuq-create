# rbcar_sim_bringup

It contains several launch files in order to launch some or all the components of the robot.

## Launching gazebo world and the robot

The following launch file launches a Gazebo empty world together with the robot controllers and gamepad to operate the robot.

```
$> roslaunch rbcar_sim_bringup rbcar_complete.launch
```

