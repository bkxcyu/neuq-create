^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_sim
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* agvs_sim: adding metapackage config
* indigo-0.1.1
* Redoing CHANGELOGS

0.1.1 (2015-07-29)
------------------
* Fixing error name on dependency
* Adding changelogs for the release
* Update package.xml
* Update package.xml
* Update CMakeLists.txt
* First indigo version commit
* Contributors: Elena Gambaro, ElenaFG, RomanRobotnik
