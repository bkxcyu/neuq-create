^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.4 (2016-07-15)
------------------
* added twist_mux cfg file
* added twist mux to accept different inputs a twist
* Contributors: rguzman1

1.0.3 (2016-07-13)
------------------

1.0.2 (2016-07-06)
------------------
* Modified authors and maintainers
* modified CMakeLists y Package files
* Contributors: carlos3dx

1.0.1 (2016-07-04)
------------------
* Modified CMakeLists and package files
* added gs world
* changed traction controllers to JointVelocityController
* updated controller parameters
* updated CMakelists.txt and package.xml
* updated controller parameters - inertia and mass still to be checked
* added rbcar_control
* Contributors: carlos3dx, rguzman, rguzman1, trurl
