^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.5 (2016-07-13)
------------------

1.0.4 (2016-07-06)
------------------
* Modified maintainers
* Contributors: carlos3dx

1.0.3 (2016-07-05)
------------------

1.0.2 (2016-07-04)
------------------

1.0.1 (2016-07-04)
------------------
* Added website
* Modified dependencies
* changed hw interface to VelocityJointInterface for traction, added damping and friction to axle and suspension
* rbcar_description: changing 3d sensor position to fit with the real model
* added imu, needed for odometry estimation
* updated urdf
* sensors imported from robotnik_sensors package
* deleted sensors - now from robotnik_sensors package
* rbcar_description: adding rviz config file
* corrected ranges of hokuyo3d and added measurement tf
* updated hokuyo3d model
* control period of plugin to 0.001 and updated traction torque
* updated model - 1st working in gazebo
* modified to work in gazebo
* changed 3d laser pos
* added rbcar_description
* Contributors: RomanRobotnik, carlos3dx, rguzman, trurl
