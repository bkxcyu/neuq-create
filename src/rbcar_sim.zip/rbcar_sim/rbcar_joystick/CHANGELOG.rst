^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_joystick
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.4 (2016-07-15)
------------------

1.0.3 (2016-07-13)
------------------

1.0.2 (2016-07-06)
------------------
* Modified authors and maintainers
* modified CMakeLists y Package files
* Contributors: carlos3dx

1.0.1 (2016-07-04)
------------------
* Modified CMakeLists and package files
* Adding compilation dependencies with robotnik_msgs
* added rbcar_joystick
* Contributors: Usuario, carlos3dx, rguzman
