^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-07-29)
------------------
* Fixing repositories in package.xml files
* agvs_description: modifying model colors
* Preparing repo for release
* Adding gitignore file and configuring dependencies
* First indigo version commit
* Contributors: Elena Gambaro, RomanRobotnik
