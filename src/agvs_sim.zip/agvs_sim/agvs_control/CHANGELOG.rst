^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* indigo-0.1.1
* Redoing CHANGELOGS

0.1.1 (2015-07-29)
------------------
* Adding changelogs for the release
* Adding the install macro to the CMakelists
* Wrong catkin package macro invocation
* Cleaning CMakelists and more
* First indigo version commit
* Contributors: Elena Gambaro, Isaac IY Saito, RomanRobotnik
