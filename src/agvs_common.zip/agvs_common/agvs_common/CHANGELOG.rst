^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_common
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-07-29)
------------------
* agvs_common: Adding options for metapackages
* Fixing repositories in package.xml files
* Corrected dependency name
* Corrected dependency name
* Preparing repo for release
* Update package.xml
* Update CMakeLists.txt
* Update package.xml
* First indigo version commit
* Contributors: Elena Gambaro, ElenaFG, RomanRobotnik
