^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_robot_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------


0.1.1 (2015-07-29)
------------------
* indigo-0.1.1
* Redoing CHANGELOGS
* agvs_robot_control: Adding build and run dependencies
* Adding changelogs for the release
* Adding the install macro to the CMakelists
* Removing old msgs for AckermanDrive
* Cleaning CMakelists and more
* First indigo version commit
* Contributors: Elena Gambaro, RomanRobotnik
