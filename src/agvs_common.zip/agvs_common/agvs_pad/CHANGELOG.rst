^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_pad
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-07-29)
------------------
* Fixing repositories in package.xml files
* Removing dependency on agvs_robot_control
* Preparing repo for release
* Adding gitignore file and configuring dependencies
* First indigo version commit
* Contributors: Elena Gambaro, RomanRobotnik
