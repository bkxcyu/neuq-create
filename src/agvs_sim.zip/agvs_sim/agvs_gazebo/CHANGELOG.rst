^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package agvs_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* indigo-0.1.1
* Redoing CHANGELOGS

0.1.1 (2015-07-29)
------------------
* agvs_gazebo: adding run dependency on agvs_pad and agvs_robot_control
* Adding changelogs for the release
* Adding the install macro to the CMakelists
* Cleaning CMakelists and more
* First indigo version commit
* Contributors: Elena Gambaro, RomanRobotnik
