# agvs_common
Agvs robot common packages. These packages are share by the simulated and real robot.

## agvs_description
This package contains the robot model (urdf, meshes, ...).

## agvs_pad
This package is intended to control the robot by a pad or joystick.
