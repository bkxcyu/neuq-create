^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rbcar_common
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.5 (2016-07-13)
------------------

1.0.4 (2016-07-06)
------------------
* Modified maintainers
* Contributors: carlos3dx

1.0.3 (2016-07-05)
------------------

1.0.2 (2016-07-04)
------------------

1.0.1 (2016-07-04)
------------------
* Added website
* Modified dependencies
* minor change
* added common mtpkg folder
* Contributors: carlos3dx, rguzman
