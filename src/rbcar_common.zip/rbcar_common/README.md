# rbcar_common
Robotnik Car common packages

## rbcar_description
It contains the [urdf](http://wiki.ros.org/urdf), meshes, and other elements needed in the description are contained here. 

##rbcar_pad
This package allows controlling the robot using a joystick or game-pad, by sending the messages received through the joystick input, correctly adapted, to the correct command topic. 
